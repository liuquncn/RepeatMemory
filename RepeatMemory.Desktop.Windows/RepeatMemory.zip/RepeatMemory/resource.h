//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RepeatMemory.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REPEATMEMORY_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_DIRECTION                   129
#define IDD_RECORD                      130
#define IDC_PATH                        1000
#define IDC_BROWSE                      1001
#define IDC_SOURCE                      1002
#define IDC_TARGET                      1003
#define IDC_HINT                        1004
#define IDC_GROUP                       1005
#define IDC_NEXT                        1006
#define IDC_FORWARD                     1007
#define IDC_SHOWHINT                    1007
#define IDC_BACKWARD                    1008
#define IDC_STATIC_SOURCE               1008
#define IDC_STATIC_TARGET               1009
#define IDC_RECORD                      1010
#define IDC_START                       1011
#define IDC_EDIT                        1012
#define IDC_SELECT                      1013
#define IDC_ANSWER                      1015
#define IDC_RICHEDIT1                   1018
#define IDC_GROUPSET                    1019
#define IDC_GRPTITLE                    1020
#define IDC_END                         1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
